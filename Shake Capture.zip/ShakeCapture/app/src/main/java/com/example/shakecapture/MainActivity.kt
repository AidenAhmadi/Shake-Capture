package com.example.shakecapture

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.abs
import java.text.SimpleDateFormat
import java.util.*

const val SHAKE_THRESHOLD = 100
class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var soundEffects: SoundEffects
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var lastAcceleration = SensorManager.GRAVITY_EARTH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        soundEffects = SoundEffects.getInstance(applicationContext)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    }

    override fun onResume() {
        super.onResume()
        //sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this, accelerometer)
    }

    fun savePhoto(view: View){
        soundEffects.playTone(true)
        takePhotoClick(view)
        Log.d("Het", "het")
    }

    private fun createImageFile(): File {

        // Create a unique filename
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val imageFilename = "photo_$timeStamp.jpg"

        // Create the file in the Pictures directory on external storage
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File(storageDir, imageFilename)
    }
    fun takePhotoClick(view: View) {

        // Create the File for saving the photo
        val photoFile = createImageFile()

        val photoUri: Uri = FileProvider.getUriForFile(
            this, "com.zybooks.camerademo.fileprovider", photoFile)

        // Start camera app
        takePicture.launch(photoUri)
    }

    private val takePicture = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            Toast.makeText(
                this, "Saved photo", Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(
                this, "Did not save photo", Toast.LENGTH_SHORT
            ).show()
        }
    }
    override fun onSensorChanged(event: SensorEvent) {
        Log.d("bet", "bet")
        val x: Float = event.values[0]
        val y: Float = event.values[1]
        val z: Float = event.values[2]
        // Find magnitude of acceleration
        val currentAcceleration: Float = x * x + y * y + z * z

        // Calculate difference between 2 readings
        val delta = currentAcceleration - lastAcceleration

        // Save for next time
        lastAcceleration = currentAcceleration

        // Detect shake
        if (abs(delta) > SHAKE_THRESHOLD) {
            Log.d("yay", "yay")
            savePhoto(findViewById(R.id.button))
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        TODO("Not yet implemented")
    }

}